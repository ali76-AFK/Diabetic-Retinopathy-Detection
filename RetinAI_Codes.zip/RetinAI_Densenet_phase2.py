#%%capture
import os
import tensorflow as tf
#tf.get_logger().setLevel('ERROR')
from tensorflow.keras import mixed_precision
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import matplotlib.image as mpimg
#cell_5
from tensorflow.keras.callbacks import Callback
from sklearn.metrics import cohen_kappa_score, f1_score, recall_score, accuracy_score
#cell_6
from tensorflow.keras import layers, models, backend
#cell_7
from tensorflow.keras import callbacks
# --- LOGGING CONFIGURATION ---
# '0' = All logs (Default)
# '1' = Hide INFO messages
# '2' = Hide INFO & WARNINGS
# '3' = Hide everything including ERRORS 
 

# --- 1. Enable Mixed Precision (Turbo Mode for A100) ---
# Uses 16-bit math for speed, but keeps 32-bit for stability.
policy = mixed_precision.Policy('mixed_float16')
mixed_precision.set_global_policy(policy)

# --- 2. Configure Memory Growth ---
# Good practice to prevent allocation errors.
gpus = tf.config.list_physical_devices('GPU')
gpu_name = "Unknown"
if gpus:
    try:
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        gpu_name = gpus[0].name
    except RuntimeError as e:
        print(e)

# --- VISIBLE OUTPUT ---
print("="*40)
print(f"System Setup Complete")
print(f"GPU Detected: {gpu_name}")
print(f"Compute Policy: {policy.name} (16-bit optimization enabled)")
print(f"TensorFlow Version: {tf.__version__}")
print("="*40)
#%%



# --- PATH SETUP ---
BASE_DIR = Path("dr-data_variantB_ben_graham")

# --- HYPERPARAMETERS ---
IMG_SIZE = (512, 512)   # High Res for detecting Microaneurysms
BATCH_SIZE = 16         # Optimized for A100
EPOCHS = 15             # Max duration
LEARNING_RATE = 1e-5    # Stable rate for Deep Networks

# --- VISIBLE OUTPUT ---
print("="*40)
print(f"Configuration Loaded")
print(f"Data Folder: {BASE_DIR.resolve()}")
print(f"Image Size: {IMG_SIZE}")
print(f"Batch Size: {BATCH_SIZE}")
print(f"Learning Rate: {LEARNING_RATE}")
print("="*40)


train_path = BASE_DIR / "train"

# 1. Check if the path exists
if not train_path.exists():
    print(f"ERROR: The path {train_path} does not exist!")
else:
    print(f"Path found: {train_path}")
    
    # 2. Find class folders (0, 1, 2, 3, 4)
    # We filter specifically for folders, ignoring hidden files like .DS_Store
    classes = [d for d in os.listdir(train_path) if os.path.isdir(train_path / d)]
    
    if len(classes) > 0:
        # Pick the first class found (e.g., '0' - No DR)
        demo_class = classes[0]
        class_path = train_path / demo_class
        
        # Pick the first image in that folder
        images = os.listdir(class_path)
        if len(images) > 0:
            img_name = images[0]
            full_img_path = class_path / img_name
            
            # 3. Display the Image
            img = mpimg.imread(full_img_path)
            plt.figure(figsize=(6,6))
            plt.imshow(img)
            plt.title(f"Found in folder: '{demo_class}'\nShape: {img.shape}")
            plt.axis('off')
            plt.show()
            print("Image loaded successfully! Your data structure is correct.")
        else:
            print(f"Class folder '{demo_class}' is empty.")
    else:
        print("No class folders (0, 1, 2...) found inside 'train'. Check directory structure.")



def process_data(image, label):
    # Normalize to 0-1
    image = tf.cast(image, tf.float32) / 255.0
    # Cast label to Float for Regression (e.g. 2 -> 2.0)
    label = tf.cast(label, tf.float32)
    return image, label

print("Scanning files...")

# 1. Train
train_ds = tf.keras.utils.image_dataset_from_directory(
    BASE_DIR / "train", seed=42, image_size=IMG_SIZE, batch_size=BATCH_SIZE, label_mode='int', shuffle=True
)

# 2. Validation
val_ds = tf.keras.utils.image_dataset_from_directory(
    BASE_DIR / "val", seed=42, image_size=IMG_SIZE, batch_size=BATCH_SIZE, label_mode='int', shuffle=False
)

# 3. Test
test_ds = tf.keras.utils.image_dataset_from_directory(
    BASE_DIR / "test", seed=42, image_size=IMG_SIZE, batch_size=BATCH_SIZE, label_mode='int', shuffle=False
)

# Optimize (Cache & Prefetch for speed)
train_ds = train_ds.map(process_data, num_parallel_calls=tf.data.AUTOTUNE).prefetch(tf.data.AUTOTUNE)
val_ds = val_ds.map(process_data, num_parallel_calls=tf.data.AUTOTUNE).prefetch(tf.data.AUTOTUNE)
test_ds = test_ds.map(process_data, num_parallel_calls=tf.data.AUTOTUNE).prefetch(tf.data.AUTOTUNE)

# --- VISIBLE OUTPUT ---
print("="*40)
print(f"Data Pipeline Ready")
print(f"Training Batches: {len(train_ds)}")
print(f"Validation Batches: {len(val_ds)}")
print(f"Test Batches: {len(test_ds)}")
print("="*40)





import tensorflow as tf
from tensorflow.keras import layers, models, backend

# --- 1. DEFINE ARCHITECTURE (So TF 2.15 knows how to build it) ---
def conv_block(x, growth_rate, name):
    x1 = layers.BatchNormalization(name=name+'_0_bn')(x)
    x1 = layers.Activation('relu', name=name+'_0_relu')(x1)
    x1 = layers.Conv2D(4 * growth_rate, 1, use_bias=False, name=name+'_1_conv', kernel_initializer='he_normal')(x1)
    x1 = layers.BatchNormalization(name=name+'_1_bn')(x1)
    x1 = layers.Activation('relu', name=name+'_1_relu')(x1)
    x1 = layers.Conv2D(growth_rate, 3, padding='same', use_bias=False, name=name+'_2_conv', kernel_initializer='he_normal')(x1)
    x = layers.Concatenate(name=name+'_concat')([x, x1])
    return x

def dense_block(x, blocks, name):
    for i in range(blocks):
        x = conv_block(x, 32, name=name+'_block' + str(i + 1))
    return x

def transition_layer(x, reduction, name):
    x = layers.BatchNormalization(name=name+'_bn')(x)
    x = layers.Activation('relu', name=name+'_relu')(x)
    filter_num = int(backend.int_shape(x)[-1] * reduction)
    x = layers.Conv2D(filter_num, 1, use_bias=False, name=name+'_conv', kernel_initializer='he_normal')(x)
    x = layers.AveragePooling2D(2, strides=2, name=name+'_pool')(x)
    return x

def build_densenet121(input_shape):
    inputs = layers.Input(shape=input_shape)
    x = layers.RandomFlip("horizontal_and_vertical")(inputs)
    x = layers.RandomRotation(0.2)(x)
    
    # Stem
    x = layers.Conv2D(64, 7, strides=2, use_bias=False, padding='same', name='conv1_conv', kernel_initializer='he_normal')(x)
    x = layers.BatchNormalization(name='conv1_bn')(x)
    x = layers.Activation('relu', name='conv1_relu')(x)
    x = layers.MaxPooling2D(3, strides=2, padding='same', name='pool1')(x)
    
    # Blocks
    x = dense_block(x, 6, name='conv2')
    x = transition_layer(x, 0.5, name='pool2')
    x = dense_block(x, 12, name='conv3')
    x = transition_layer(x, 0.5, name='pool3')
    x = dense_block(x, 24, name='conv4')
    x = transition_layer(x, 0.5, name='pool4')
    x = dense_block(x, 16, name='conv5')
    
    # Head
    x = layers.GlobalAveragePooling2D(name='avg_pool')(x)
    x = layers.Dropout(0.5)(x)
    outputs = layers.Dense(1, activation='linear', dtype='float32', name='severity_score')(x)
    
    return models.Model(inputs, outputs, name='DenseNet121_Custom')

# --- 2. BUILD MODEL ---
print("🏗️ Re-building Model Architecture...")
model = build_densenet121((512, 512, 3))

# --- 3. LOAD WEIGHTS ---
print("Loading Weights from 'best_densenet_a100.keras'...")
try:
    # We load ONLY weights. We skip mismatches to be safe across versions.
    model.load_weights('best_densenet_a100.keras', skip_mismatch=True, by_name=True)
    print("Success! Weights loaded.")
except Exception as e:
    print(f"Error loading weights: {e}")
    print("   Make sure the file 'best_densenet_a100.keras' is in the file browser.")

# --- 4. COMPILE ---
model.compile(
    optimizer=tf.keras.optimizers.Adam(learning_rate=1e-5),
    loss='mse',
    metrics=['mae']
)
print("Model Compiled. Ready for Training.")







# Grab one batch
images, labels = next(iter(train_ds))

plt.figure(figsize=(10, 10))
for i in range(9):
    ax = plt.subplot(3, 3, i + 1)
    plt.imshow(images[i])
    plt.title(f"Severity: {labels[i]:.1f}") # Shows 0.0, 1.0 etc
    plt.axis("off")

# --- VISIBLE OUTPUT ---
print(" Visualization Generated below.")
plt.show()




from tensorflow.keras.callbacks import Callback

class MedicalMetrics(Callback):
    def __init__(self, val_ds):
        super().__init__()
        self.val_ds = val_ds

    def on_epoch_end(self, epoch, logs=None):
        print(f"\n   Checking metrics on Ben Graham data (Epoch {epoch+1})...")
        y_true_list = []
        y_pred_list = []

        # RAM-Safe Loop (Batch by Batch)
        for x_batch, y_batch in self.val_ds:
            preds = self.model.predict(x_batch, verbose=0)
            preds = np.clip(np.round(preds).flatten(), 0, 4)
            y_pred_list.extend(preds)
            y_true_list.extend(y_batch.numpy())

        y_true = np.array(y_true_list)
        y_pred = np.array(y_pred_list)

        # Calculate Metrics
        kappa = cohen_kappa_score(y_true, y_pred, weights='quadratic')
        recall = recall_score(y_true, y_pred, average='macro')
        f1 = f1_score(y_true, y_pred, average='macro')
        acc = accuracy_score(y_true, y_pred)

        print(f" — val_kappa: {kappa:.4f} — val_recall: {recall:.4f} — val_f1: {f1:.4f} — val_acc: {acc:.4f}")
        
        # Save to history
        logs['val_kappa'] = kappa
        logs['val_recall'] = recall
        logs['val_f1'] = f1
        logs['val_acc'] = acc

metrics_callback = MedicalMetrics(val_ds)
print(" Callback Initialized.")




# 1. Compile with TINY Learning Rate (1e-5)
# We want to gently adapt the weights, not destroy them.
model.compile(
    optimizer=tf.keras.optimizers.Adam(learning_rate=LEARNING_RATE), 
    loss='mse',
    metrics=['mae']
)

# 2. Callbacks
my_callbacks = [
    # IMPORTANT: Save to a NEW file name!
    callbacks.ModelCheckpoint('ben_graham_finetuned.keras', save_best_only=True, monitor='val_loss'),
    callbacks.EarlyStopping(monitor='val_loss', patience=6, restore_best_weights=True),
    metrics_callback
]

# 3. Train
print("🚀 Starting Fine-Tuning on Ben Graham Data...")
history_finetune = model.fit(
    train_ds,
    validation_data=val_ds,
    epochs=EPOCHS, 
    callbacks=my_callbacks
)






hist = history_finetune.history
epochs_range = range(len(hist['loss']))

plt.figure(figsize=(20, 5))

# Loss
plt.subplot(1, 3, 1)
plt.plot(epochs_range, hist['loss'], label='Train Loss')
plt.plot(epochs_range, hist['val_loss'], label='Val Loss')
plt.title('Fine-Tuning Loss')
plt.legend()

# Kappa
plt.subplot(1, 3, 2)
if 'val_kappa' in hist:
    plt.plot(epochs_range, hist['val_kappa'], label='Kappa', color='green')
    plt.title('Kappa Adaptation')
    plt.legend()

# Recall
plt.subplot(1, 3, 3)
if 'val_recall' in hist:
    plt.plot(epochs_range, hist['val_recall'], label='Recall', color='orange')
    plt.title('Recall Adaptation')
    plt.legend()

plt.show()





import numpy as np
import tensorflow as tf

print("Generating Predictions on Validation Set...")

y_true_list = []
y_pred_list = []

# Loop through batches to stay memory safe
for x_batch, y_batch in val_ds:
    # 1. Predict
    preds = model.predict(x_batch, verbose=0)
    
    # 2. Flatten and just keep the raw numbers for now
    y_pred_list.extend(preds.flatten())
    y_true_list.extend(y_batch.numpy())

# Convert to numpy arrays
y_true = np.array(y_true_list)
y_raw_preds = np.array(y_pred_list)

print(f"Prediction Complete. Scored {len(y_true)} images.")






import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, cohen_kappa_score

# 1. Convert Scores to Classes (Standard Rounding)
# < 0.5 becomes 0, > 3.5 becomes 4
y_pred_classes = np.clip(np.round(y_raw_preds), 0, 4).astype(int)

# 2. Calculate Final Kappa
kappa = cohen_kappa_score(y_true, y_pred_classes, weights='quadratic')
print(f"Final Quadratic Kappa Score: {kappa:.4f}")

# 3. Create Matrix
cm = confusion_matrix(y_true, y_pred_classes)

# 4. Plot
plt.figure(figsize=(10, 8))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=False, annot_kws={"size": 12})

plt.title(f'Confusion Matrix (Kappa: {kappa:.4f})', fontsize=15)
plt.xlabel('Predicted Label (AI)', fontsize=12)
plt.ylabel('True Label (Doctor)', fontsize=12)
plt.show()





from sklearn.metrics import cohen_kappa_score
import numpy as np

# 1. Get Raw Predictions
print("⏳ Getting raw scores...")
y_pred_raw = model.predict(val_ds, verbose=0).flatten()

y_true_list = []
for x, y in val_ds:
    y_true_list.extend(y.numpy())
y_true = np.array(y_true_list)

# 2. Optimizer Function
def get_kappa(cuts, preds, targets):
    p = np.zeros(preds.shape)
    p[(preds >= cuts[0]) & (preds < cuts[1])] = 1
    p[(preds >= cuts[1]) & (preds < cuts[2])] = 2
    p[(preds >= cuts[2]) & (preds < cuts[3])] = 3
    p[preds >= cuts[3]] = 4
    return cohen_kappa_score(targets, p.astype(int), weights='quadratic')

print("🔄 Searching for Best Thresholds...")
best_kappa = -1
best_thr = []

# Search grid (Focusing on lowering the top threshold)
# Standard is [0.5, 1.5, 2.5, 3.5]
# We test lowering the 3.5 to 3.0 to catch those Grade 4s
for t0 in np.arange(0.3, 0.6, 0.1):
    for t1 in np.arange(1.3, 1.7, 0.1):
        for t2 in np.arange(2.3, 2.7, 0.1):
            for t3 in np.arange(2.9, 3.5, 0.1): # <--- Important range
                current_thr = [t0, t1, t2, t3]
                score = get_kappa(current_thr, y_pred_raw, y_true)
                if score > best_kappa:
                    best_kappa = score
                    best_thr = current_thr

print("\n🏆 RESULTS:")
print(f"Old Kappa: 0.7811")
print(f"New Kappa: {best_kappa:.4f}")
print(f"Best Thresholds: {best_thr}")






import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
if 'best_thr' not in locals():
    print("⚠️ Warning: 'best_thr' not found. Using defaults.")
    best_thr = [0.5, 1.5, 2.3, 3.1]

print(f"Applying Thresholds: {best_thr}")

# 1. Apply Logic
# < T1 -> 0
# T1 to T2 -> 1
# T2 to T3 -> 2
# T3 to T4 -> 3
# > T4 -> 4
final_preds = np.zeros(y_pred_raw.shape)
final_preds[(y_pred_raw >= best_thr[0]) & (y_pred_raw < best_thr[1])] = 1
final_preds[(y_pred_raw >= best_thr[1]) & (y_pred_raw < best_thr[2])] = 2
final_preds[(y_pred_raw >= best_thr[2]) & (y_pred_raw < best_thr[3])] = 3
final_preds[y_pred_raw >= best_thr[3]] = 4

# 2. Create Matrix
cm = confusion_matrix(y_true, final_preds)

# 3. Plot
plt.figure(figsize=(10, 8))
sns.heatmap(cm, annot=True, fmt='d', cmap='Greens', cbar=False, annot_kws={"size": 12})

plt.title(f'Optimized Confusion Matrix (Kappa: {best_kappa:.4f})', fontsize=15)
plt.xlabel('Predicted Label', fontsize=12)
plt.ylabel('True Label', fontsize=12)
plt.show()

# 4. Critical Check (Did we fix the Class 4 issue?)
grade4_caught = cm[4,4]
grade4_missed_as_3 = cm[4,3]
print(f"Grade 4 Correctly Predicted: {grade4_caught}")
print(f"Grade 4 Mistaken for Grade 3: {grade4_missed_as_3}")





